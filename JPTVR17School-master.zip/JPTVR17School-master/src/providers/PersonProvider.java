
package providers;

import entity.Person;
import java.util.Scanner;


public class PersonProvider {

    public Person createPerson() {
        Scanner scanner = new Scanner(System.in);
        Person person = new Person();
        System.out.println("-------Добавление Ученика--------");
        String inputNumber = "";
        Long id = null;
        boolean flag = true;
        do{
           System.out.print("Идентификатор ученика: ");
           inputNumber = scanner.nextLine();
           try {
              id=new Long(inputNumber);
              flag = false;
           }catch (Exception e){
               System.out.println("Ошибка ввода!");
           }
        }while(flag);
        person.setId(id);
        System.out.print("Имя ученика: ");
        person.setName(scanner.nextLine());
        System.out.print("Фамилия ученика: ");
        person.setSurname(scanner.nextLine());
        System.out.print("Статус: ");
        person.setStatus(scanner.nextLine());
        
        return person;
    }

}
