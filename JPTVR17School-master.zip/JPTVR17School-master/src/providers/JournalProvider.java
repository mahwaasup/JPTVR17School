package providers;

import entity.Journal;
import entity.Person;
import entity.SubjectName;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Scanner;

public class JournalProvider {
    private Scanner scanner = new Scanner(System.in);
    public Journal createJournal(List<Person> listPersons, List<SubjectName> listSubjectsName) {
        Scanner scanner = new Scanner(System.in);
        Journal journal = new Journal();
        System.out.println("-------Выдать Оценку--------");
        System.out.print("Список Учеников:");
        for(int i=0; i<listPersons.size();i++){
            System.out.printf("%d. %s %s%n", 
                    i+1,
                    listPersons.get(i).getName(),
                    listPersons.get(i).getSurname()
            );
        }
        System.out.print("Список Предметов: ");
        for(int i=0; i<listSubjectsName.size();i++){
            System.out.printf("%d. %s %s%n", 
                    i+1,
                    listSubjectsName.get(i).getName(),
                    listSubjectsName.get(i).getAuthor(),
                    listSubjectsName.get(i).getLanguage()
            );
        }
        System.out.print("Выберите номер ученика: ");
        String numberPerson = scanner.nextLine();
        System.out.print("Выберите номер предмета: ");
        String numberSubject = scanner.nextLine();
        Person person = listPersons.get(new Integer(numberPerson)-1);
        SubjectName subject = listSubjectsName.get(new Integer(numberSubject) - 1);
        journal.setStudent(person);
        journal.setSubject(subject);
        System.out.print("Оценка: ");
        journal.setGrade(Integer.parseInt(scanner.nextLine()));
        Calendar c = new GregorianCalendar();
        journal.setDate(new Date());
        return journal;
    }
}
