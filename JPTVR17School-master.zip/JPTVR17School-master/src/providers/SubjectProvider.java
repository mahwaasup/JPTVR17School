
package providers;

import entity.SubjectName;
import java.util.Scanner;

public class SubjectProvider {
    
    public SubjectName createSubject() {
        Scanner scanner = new Scanner(System.in);
        SubjectName subject = new SubjectName();
        System.out.println("-------Добавление Предмета--------");
        String inputNumber = "";
        Long id = null;
        boolean flag = true;
        do{
           System.out.print("Идентификатор предмета: ");
           inputNumber = scanner.nextLine();
           try {
              id=new Long(inputNumber);
              flag = false;
           }catch (Exception e){
               System.out.println("Ошибка ввода!");
           }
        }while(flag);
        subject.setId(id);
        System.out.print("Название предмета: ");
        subject.setName(scanner.nextLine());
        System.out.print("Учитель: ");
        subject.setAuthor(scanner.nextLine());
        System.out.print("Язык: ");
        subject.setLanguage(scanner.nextLine());
        
        return subject;
    }
}
