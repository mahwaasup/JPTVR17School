
package interfaces;

import entity.Person;
import entity.Journal;
import entity.SubjectName;
import java.util.List;

/**
 *
 * @author Melnikov
 */
public interface Savable {
    void savePersons(List<Person> listPersons);
    List<Person> loadPersonsFromStorage();
    List<SubjectName> loadSubjectsNameFromStorage();
    void saveSubjectsName(List<SubjectName> listSubjectsName);
    List<Journal> loadJournalsFromStorage();
    void saveJournals(List<Journal> listJournals);
}
