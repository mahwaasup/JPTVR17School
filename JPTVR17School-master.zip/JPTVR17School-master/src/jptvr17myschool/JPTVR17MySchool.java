package jptvr17myschool;

public class JPTVR17MySchool {
    
    public static void main(String[] args) {
        App app = new App();
        app.run();
    }
    
}