package jptvr17myschool;

import entity.Journal;
import entity.Person;
import entity.SubjectName;
import interfaces.Savable;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class StorageInFile implements Savable  {
   public void savePersons(List<Person> listPersons) {
        FileOutputStream fos = null;
        ObjectOutputStream oos = null;
       try {
           fos = new FileOutputStream("Person.txt"); 
           oos = new ObjectOutputStream(fos);
           oos.writeObject(listPersons);
           oos.flush();
           oos.close();
       } catch (FileNotFoundException ex) {
           Logger.getLogger(StorageInFile.class.getName()).log(Level.SEVERE, "Не удалось найти файл", ex);
       } catch (IOException ex) {
           Logger.getLogger(StorageInFile.class.getName()).log(Level.SEVERE, "Не удалось найти файл",ex);
       }
    }

    public List<Person> loadPersonsFromStorage() {
            List<Person> person = new ArrayList<>();
            FileInputStream fis = null;
            ObjectInputStream oin = null;
       try {
           fis = new FileInputStream("Person.txt");
           oin = new ObjectInputStream(fis);
           person = (List<Person>) oin.readObject();
       } catch (FileNotFoundException ex) {
           Logger.getLogger(StorageInFile.class.getName()).log(Level.SEVERE,"Не удалось найти файл", ex);
       } catch (IOException ex) {
           Logger.getLogger(StorageInFile.class.getName()).log(Level.SEVERE, "Не удалось найти файл", ex);
       } catch (ClassNotFoundException ex) {
           Logger.getLogger(StorageInFile.class.getName()).log(Level.SEVERE, null, ex);
       } 
        return person;
    }

   public List<Journal> loadJournalsFromStorage() {
        List<Journal> journal = new ArrayList<>();
            FileInputStream fis = null;
            ObjectInputStream oin = null;
       try {
           fis = new FileInputStream("Journal.txt");
           oin = new ObjectInputStream(fis);
           journal = (List<Journal>) oin.readObject();
       } catch (FileNotFoundException ex) {
           Logger.getLogger(StorageInFile.class.getName()).log(Level.SEVERE, "Не удалось найти файл", ex);
       } catch (IOException ex) {
           Logger.getLogger(StorageInFile.class.getName()).log(Level.SEVERE, "Не удалось найти файл", ex);
       } catch (ClassNotFoundException ex) {
           Logger.getLogger(StorageInFile.class.getName()).log(Level.SEVERE, "Не удалось найти файл", ex);
       }
        
        return journal;
    }

    public void saveJournals(List<Journal> listJournal) {
        FileOutputStream fos = null;
        ObjectOutputStream oos = null;
       try {
           fos = new FileOutputStream("Journal.txt");
           oos = new ObjectOutputStream(fos);
           oos.writeObject(listJournal);
           oos.flush();
           oos.close();
       } catch (FileNotFoundException ex) {
           Logger.getLogger(StorageInFile.class.getName()).log(Level.SEVERE, "Не удалось найти файл", ex);
       } catch (IOException ex) {
           Logger.getLogger(StorageInFile.class.getName()).log(Level.SEVERE, "Не удалось найти файл", ex);
       }
         
    }

    public List<SubjectName> loadSubjectsNameFromStorage(){
        List<SubjectName> subjectname = new ArrayList<>();
            FileInputStream fis = null;
            ObjectInputStream oin = null;
       try {
           fis = new FileInputStream("SubjectName.txt");
           oin = new ObjectInputStream(fis);
           subjectname = (List<SubjectName>) oin.readObject();
       } catch (FileNotFoundException ex) {
           Logger.getLogger(StorageInFile.class.getName()).log(Level.SEVERE, "Не удалось найти файл", ex);
       } catch (IOException ex) {
           Logger.getLogger(StorageInFile.class.getName()).log(Level.SEVERE, "Не удалось найти файл", ex);
       } catch (ClassNotFoundException ex) {
           Logger.getLogger(StorageInFile.class.getName()).log(Level.SEVERE, "Не удалось найти файл", ex);
       }
        return subjectname;
    }

   @Override
    public void saveSubjectsName(List<SubjectName> listSubjectsName) {
        FileOutputStream fos = null;
        ObjectOutputStream oos = null;
       try {
           fos = new FileOutputStream("SubjectName.txt");
           oos = new ObjectOutputStream(fos);
           oos.writeObject(listSubjectsName);
           oos.flush();
           oos.close();
       } catch (FileNotFoundException ex) {
           Logger.getLogger(StorageInFile.class.getName()).log(Level.SEVERE, "Не удалось найти файл", ex);
       } catch (IOException ex) {
           Logger.getLogger(StorageInFile.class.getName()).log(Level.SEVERE, "Не удалось найти файл", ex);
       }

    }
    
}
