package jptvr17myschool;

import entity.Journal;
import entity.Person;
import entity.SubjectName;
import java.util.List;
import interfaces.Savable;
import java.util.ArrayList;
import java.util.Scanner;
import providers.PersonProvider;
import providers.JournalProvider;
import providers.SubjectProvider;

public class App {
       private List<Person> listPersons = new ArrayList<>();
       private List<SubjectName> listSubjectsName = new ArrayList<>();
       private List<Journal> listJournals = new ArrayList<>();
       
       private Savable savable;

    public App() {
       // savable = new StorageInBase();
        savable = new StorageInFile();
        
        try {
            listPersons = savable.loadPersonsFromStorage();
        } catch (Exception e) {
            System.out.println("Нет данных");
        }
       
        try {
            listJournals = savable.loadJournalsFromStorage();
        } catch (Exception e) {
            System.out.println("Нет данных");
        }
        try {
            listSubjectsName = savable.loadSubjectsNameFromStorage();
        } catch (Exception e) {
            System.out.println("Нет данных");
        }
    }
    
    public void run() {
        
        Scanner scanner = new Scanner(System.in);
        System.out.println("---- Журнал ----");
        String repeat = "r";
        int operation;
        do{
            System.out.println("Выберите действие:");
            System.out.println("");
            System.out.println("1. Посмотреть список учеников");
            System.out.println("2. Добавить ученика");
            System.out.println("3. Посмотреть оценки");
            System.out.println("4. Выставить оценку");
            System.out.println("5. Посмотреть список предметов");
            System.out.println("6. Добавить предмет");
            operation = scanner.nextInt();
            scanner.nextLine();
            switch (operation) {
                case 1:
                    System.out.println("Список учеников: ");
                    for(int i=0;i<listPersons.size();i++){
                        System.out.println(listPersons.get(i));
                    }
                    break;
                case 2:
                    PersonProvider personProvider = new PersonProvider();
                    listPersons.add(personProvider.createPerson());
                    savable.savePersons(listPersons);
                    for(int i=0; i < listPersons.size();i++){
                       System.out.println(
                            "Список учеников: " 
                            + listPersons.get(i).getName()
                        ); 
                    }
                    break;
                case 3:
                    System.out.println("Список Оценок: ");
                    for(int i=0;i<listJournals.size();i++){
                        System.out.println(listJournals.get(i));
                    }
                    break;
                case 4:
                    JournalProvider journalprovider = new JournalProvider();
                    listJournals.add(journalprovider.createJournal(
                            listPersons,
                            listSubjectsName
                    ));
                    savable.saveJournals(listJournals);
                    break;
                case 5:
                    System.out.println("Список предметов: ");
                    for(int i=0;i<listSubjectsName.size();i++){
                        System.out.println(listSubjectsName.get(i));
                    }
                    break;
                case 6:
                    SubjectProvider subjectProvider = new SubjectProvider();
                    listSubjectsName.add(subjectProvider.createSubject());
                    savable.saveSubjectsName(listSubjectsName);
                    for(int i=0; i < listSubjectsName.size();i++){
                       System.out.println(
                            "Список предметов: " 
                            + listSubjectsName.get(i).getName()
                        ); 
                    }
                    break;
                default:
                    System.out.println("Такое действие не поддерживается");
                    continue;
            }
            System.out.println("Для продолжения");
            System.out.println("введите \"r\"");
            System.out.println("Для окончания");
            System.out.println("введите \"q\"");
            repeat = scanner.nextLine();
        }while("r".equals(repeat));
        System.out.println("Жкрнал закрывается");
        
    }
       
}
